Hello Future Tania,

There are a lot of files in this folder, do not fear 99% of them we did not in fact touch, they were configured by the create-react-app set up detailed in the beginning of reactApp.md. the only files we changed were App.js and we added the components file.
